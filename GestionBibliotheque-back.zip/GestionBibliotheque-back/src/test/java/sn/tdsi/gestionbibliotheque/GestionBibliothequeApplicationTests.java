package sn.tdsi.gestionbibliotheque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionBibliothequeApplicationTests {

	@Test
	void contextLoads() {
	}

}
