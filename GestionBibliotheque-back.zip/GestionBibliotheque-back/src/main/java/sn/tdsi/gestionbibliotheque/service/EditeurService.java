package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.entity.Editeur;

import java.util.List;

public interface EditeurService {
    boolean ajouterEditeur(Editeur editeur);
    boolean modifierEditeur(Editeur editeur);
    boolean supprimerEditeur(Long idEditeur);
    Editeur getEditeurParId(Long idEditeur);
    List<Editeur> getTousLesEditeurs();
}
