package sn.tdsi.gestionbibliotheque.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.service.EcrireService;

import java.util.List;

@RestController
@RequestMapping("/api/associations-auteurs-livres")
@CrossOrigin("*")
public class EcrireController {

    private final EcrireService ecrireService;

    public EcrireController(EcrireService ecrireService) {
        this.ecrireService = ecrireService;
    }

    /**
     * Associe un auteur à un livre.
     * Correction : Utilisation de Long pour matcher avec le service et JPA.
     * Exemple : POST /api/associations-auteurs-livres/associer?idAuteur=1&idLivre=5
     */
    @PostMapping("/associer")
    public ResponseEntity<String> associer(@RequestParam Long idAuteur, @RequestParam Long idLivre) {
        boolean success = ecrireService.associerAuteurLivre(idAuteur, idLivre);
        if (success) {
            return new ResponseEntity<>("Association créée avec succès.", HttpStatus.CREATED);
        } else {
            // Un 409 Conflict ou 400 Bad Request est plus approprié qu'une erreur 500
            return new ResponseEntity<>("L'association existe déjà ou l'ID est introuvable.", HttpStatus.CONFLICT);
        }
    }

    /**
     * Supprime l'association entre un auteur et un livre.
     */
    @DeleteMapping("/dissocier")
    public ResponseEntity<Void> dissocier(@RequestParam Long idAuteur, @RequestParam Long idLivre) {
        boolean success = ecrireService.dissocierAuteurLivre(idAuteur, idLivre);
        if (success) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Récupère la liste des IDs des auteurs pour un livre donné.
     */
    @GetMapping("/livre/{idLivre}/auteurs")
    public ResponseEntity<List<Long>> getIdsAuteursParLivre(@PathVariable Long idLivre) {
        return ResponseEntity.ok(ecrireService.getIdsAuteursParLivre(idLivre));
    }

    /**
     * Récupère la liste des IDs des livres pour un auteur donné.
     */
    @GetMapping("/auteur/{idAuteur}/livres")
    public ResponseEntity<List<Long>> getIdsLivresParAuteur(@PathVariable Long idAuteur) {
        return ResponseEntity.ok(ecrireService.getIdsLivresParAuteur(idAuteur));
    }
}