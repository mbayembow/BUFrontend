package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.LivreDTO;
import sn.tdsi.gestionbibliotheque.entity.Livre;

@Mapper(componentModel = "spring")
public interface LivreMapper {
    LivreDTO toDTO(Livre livre);
    Livre fromDTO(LivreDTO dto);
}
