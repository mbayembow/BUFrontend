package sn.tdsi.gestionbibliotheque.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@Entity
@Table(name = "emprunt")
@AllArgsConstructor
@NoArgsConstructor
public class Emprunt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_emprunt")
    private Long idEmprunt;

    @Column(name = "date_emprunt") // Peut être null au moment de la demande
    private LocalDate dateEmprunt;

    @Column(name = "date_retour")
    private LocalDate dateRetour;

    @Column(name = "date_demande", nullable = false)
    private LocalDate dateDemande;

    @Enumerated(EnumType.STRING)
    @Column(name = "statut", nullable = false, length = 20)
    private Statut statut;

    @ManyToOne
    @JoinColumn(name = "id_utilisateur", nullable = false)
    @JsonIgnoreProperties({"emprunts", "password", "role"}) // Empêche la récursion vers l'utilisateur
    private Utilisateur utilisateur;

    @ManyToOne
    @JoinColumn(name = "id_livre", nullable = false)
    @JsonIgnoreProperties({"emprunts", "auteurs", "categorie"}) // Empêche la récursion vers le livre
    private Livre livre;

    @ManyToOne
    @JoinColumn(name = "id_personnel")
    @JsonIgnoreProperties({"emprunts", "motDePasse"}) // Empêche la récursion vers le personnel
    private Personnel personnel;

    public enum Statut {
        En_attente,
        Valide,
        Refuse,
        Retourne
    }

    public boolean isEnRetard() {
        if (statut == Statut.Retourne) return false;
        return dateRetour != null && LocalDate.now().isAfter(dateRetour);
    }
}