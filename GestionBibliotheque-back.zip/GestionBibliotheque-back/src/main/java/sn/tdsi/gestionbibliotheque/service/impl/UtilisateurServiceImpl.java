package sn.tdsi.gestionbibliotheque.service.impl;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import sn.tdsi.gestionbibliotheque.entity.Utilisateur;
import sn.tdsi.gestionbibliotheque.repository.UtilisateurRepository;
import sn.tdsi.gestionbibliotheque.service.UtilisateurService;

import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class UtilisateurServiceImpl implements UtilisateurService {

    private final UtilisateurRepository utilisateurRepository;
    private final MessageSource messageSource;

    // ================= INSCRIPTION =================
    @Override
    public boolean inscrireUtilisateur(Utilisateur utilisateur) {
        if (utilisateurRepository.existsByEmail(utilisateur.getEmail())) {
            throw new IllegalArgumentException(
                    messageSource.getMessage(
                            "utilisateur.email.existe",
                            null,
                            Locale.getDefault()
                    )
            );
        }
        utilisateurRepository.save(utilisateur);
        return true;
    }

    // ================= MODIFICATION =================
    @Override
    public boolean modifierUtilisateur(Utilisateur utilisateur) {
        Long id = utilisateur.getIdUtilisateur();
        if (id == null) {
            throw new IllegalArgumentException(
                    messageSource.getMessage(
                            "utilisateur.id.null",
                            null,
                            Locale.getDefault()
                    )
            );
        }

        utilisateurRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "utilisateur.notfound",
                                new Object[]{id},
                                Locale.getDefault()
                        )
                ));

        utilisateurRepository.save(utilisateur);
        return true;
    }

    // ================= SUPPRESSION =================
    @Override
    public boolean supprimerUtilisateur(Long idUtilisateur) {
        Utilisateur utilisateur = utilisateurRepository.findById(idUtilisateur)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "utilisateur.notfound",
                                new Object[]{idUtilisateur},
                                Locale.getDefault()
                        )
                ));

        utilisateurRepository.delete(utilisateur);
        return true;
    }

    // ================= RECHERCHE PAR ID =================
    @Override
    public Utilisateur getUtilisateurParId(Long idUtilisateur) {
        return utilisateurRepository.findById(idUtilisateur)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "utilisateur.notfound",
                                new Object[]{idUtilisateur},
                                Locale.getDefault()
                        )
                ));
    }

    // ================= LISTE =================
    @Override
    public List<Utilisateur> getTousLesUtilisateurs() {
        return utilisateurRepository.findAll();
    }

    // ================= AUTHENTIFICATION =================
    @Override
    public Utilisateur authentifierUtilisateur(String email, String motDePasse) {
        Utilisateur utilisateur = utilisateurRepository.findByEmail(email)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "utilisateur.notfound.email",
                                new Object[]{email},
                                Locale.getDefault()
                        )
                ));

        if (!utilisateur.getMotDePasse().equals(motDePasse)) {
            throw new IllegalArgumentException(
                    messageSource.getMessage(
                            "utilisateur.badcredentials",
                            null,
                            Locale.getDefault()
                    )
            );
        }

        return utilisateur;
    }

    // ================= RECHERCHE =================
    @Override
    public List<Utilisateur> rechercherUtilisateurs(String critere) {
        return utilisateurRepository
                .findByNomContainingIgnoreCaseOrPrenomContainingIgnoreCase(critere, critere);
    }

    // ================= CHANGEMENT MOT DE PASSE =================
    @Override
    public boolean changerMotDePasse(Long idUtilisateur, String ancienMotDePasse, String nouveauMotDePasse) {
        Utilisateur utilisateur = utilisateurRepository.findById(idUtilisateur)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "utilisateur.notfound",
                                new Object[]{idUtilisateur},
                                Locale.getDefault()
                        )
                ));

        if (!utilisateur.getMotDePasse().equals(ancienMotDePasse)) {
            throw new IllegalArgumentException(
                    messageSource.getMessage(
                            "utilisateur.incorrectPassW",
                            null,
                            Locale.getDefault()
                    )
            );
        }

        utilisateur.setMotDePasse(nouveauMotDePasse);
        utilisateurRepository.save(utilisateur);
        return true;
    }

    // ================= EMAIL EXISTE =================
    @Override
    public boolean estEmailDejaUtilise(String email) {
        return utilisateurRepository.existsByEmail(email);
    }
}
