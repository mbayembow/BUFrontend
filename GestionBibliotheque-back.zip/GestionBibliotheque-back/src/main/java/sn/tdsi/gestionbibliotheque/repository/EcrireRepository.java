package sn.tdsi.gestionbibliotheque.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sn.tdsi.gestionbibliotheque.entity.Ecrire;

import java.util.List;
import java.util.Optional;
@Repository
public interface EcrireRepository extends JpaRepository<Ecrire, Long> {

    // On remplace _Id par _IdAuteur et _IdLivre
    boolean existsByAuteur_IdAuteurAndLivre_IdLivre(Long idAuteur, Long idLivre);

    Optional<Ecrire> findByAuteur_IdAuteurAndLivre_IdLivre(Long idAuteur, Long idLivre);

    List<Ecrire> findByLivre_IdLivre(Long idLivre);

    List<Ecrire> findByAuteur_IdAuteur(Long idAuteur);
}