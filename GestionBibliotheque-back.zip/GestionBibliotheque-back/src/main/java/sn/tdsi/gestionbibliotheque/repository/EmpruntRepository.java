package sn.tdsi.gestionbibliotheque.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sn.tdsi.gestionbibliotheque.entity.Emprunt;

import java.util.List;

@Repository
public interface EmpruntRepository extends JpaRepository<Emprunt, Long> {

    // Cherche l'ID "idUtilisateur" dans l'objet "utilisateur"
    List<Emprunt> findByUtilisateur_IdUtilisateur(Long idUtilisateur);

    // Cherche l'ID "idLivre" dans l'objet "livre"
    List<Emprunt> findByLivre_IdLivre(Long idLivre);

    // Celles-ci fonctionneront car "statut" existe directement dans Emprunt
    List<Emprunt> findByStatut(Emprunt.Statut statut);
}
