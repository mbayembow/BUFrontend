package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.EditeurDTO;
import sn.tdsi.gestionbibliotheque.entity.Editeur;

@Mapper(componentModel = "spring")
public interface EditeurMapper {
    EditeurDTO toDTO(Editeur editeur);
    Editeur fromDTO(EditeurDTO dto);
}
