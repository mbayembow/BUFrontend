package sn.tdsi.gestionbibliotheque.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sn.tdsi.gestionbibliotheque.entity.*;
@Repository
public interface AuteurRepository extends JpaRepository<Auteur,Long> {
}
