package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.dto.AuteurDTO;

import java.util.List;

public interface AuteurService {

    AuteurDTO createAuteur(AuteurDTO dto);

    AuteurDTO updateAuteur(Long id, AuteurDTO dto);

    void deleteAuteur(Long id);

    AuteurDTO getAuteurById(Long id);

    List<AuteurDTO> getAllAuteurs();

    List<AuteurDTO> searchAuteurs(String critere);
}
