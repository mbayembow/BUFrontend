package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.entity.Personnel;
import java.util.List;

public interface PersonnelService {

    boolean ajouterPersonnel(Personnel personnel);

    boolean modifierPersonnel(Personnel personnel);

    boolean supprimerPersonnel(Long idPersonnel);

    Personnel getPersonnelParId(Long idPersonnel);

    List<Personnel> getTousLesPersonnels();

    Personnel authentifierPersonnel(String email, String motDePasse);

    List<Personnel> rechercherPersonnels(String critere);

    boolean changerMotDePasse(Long idPersonnel, String ancienMotDePasse, String nouveauMotDePasse);

    boolean estEmailDejaUtilise(String email);
}
