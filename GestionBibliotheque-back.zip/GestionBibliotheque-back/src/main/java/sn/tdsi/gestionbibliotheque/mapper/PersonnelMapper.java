package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.PersonnelDTO;
import sn.tdsi.gestionbibliotheque.entity.Personnel;

@Mapper(componentModel = "spring")
public interface PersonnelMapper {
    PersonnelDTO toDTO(Personnel personnel);
    Personnel fromDTO(PersonnelDTO dto);
}
