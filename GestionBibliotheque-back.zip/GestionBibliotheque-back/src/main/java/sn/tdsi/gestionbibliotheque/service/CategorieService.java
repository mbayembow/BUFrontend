package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.dto.CategorieDTO;
import java.util.List;

public interface CategorieService {

    // Créer une nouvelle catégorie
    CategorieDTO createCategorie(CategorieDTO categorieDTO);

    // Mettre à jour une catégorie existante
    CategorieDTO updateCategorie(int id, CategorieDTO categorieDTO);

    // Supprimer une catégorie par son ID
    void deleteCategorie(int id);

    // Récupérer une catégorie par son ID
    CategorieDTO getCategorieById(int id);

    // Récupérer toutes les catégories
    List<CategorieDTO> getAllCategories();

    // Rechercher une catégorie par nom
    CategorieDTO getCategorieByNom(String nom);

    // Vérifier si le nom de catégorie existe déjà
    boolean isNomCategorieDejaUtilise(String nom);
}
