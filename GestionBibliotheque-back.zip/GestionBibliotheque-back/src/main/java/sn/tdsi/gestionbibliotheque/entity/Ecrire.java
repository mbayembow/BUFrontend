package sn.tdsi.gestionbibliotheque.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "ecrire")
@AllArgsConstructor
@NoArgsConstructor
public class Ecrire {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ecrire")
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_auteur", nullable = false)
    // On ignore le champ qui liste les livres dans l'entité Auteur pour couper la boucle
    @JsonIgnoreProperties({"ecritures", "biographie", "nationalite"})
    private Auteur auteur;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_livre", nullable = false)
    // On ignore le champ qui liste les auteurs dans l'entité Livre
    @JsonIgnoreProperties({"ecritures", "resume", "categorie"})
    private Livre livre;

    public Ecrire(Auteur auteur, Livre livre) {
        this.auteur = auteur;
        this.livre = livre;
    }
}