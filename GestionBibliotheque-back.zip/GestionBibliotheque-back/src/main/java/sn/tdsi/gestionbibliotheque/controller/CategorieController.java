package sn.tdsi.gestionbibliotheque.controller;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.dto.CategorieDTO;
import sn.tdsi.gestionbibliotheque.service.CategorieService;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@CrossOrigin("*")
public class CategorieController {

    private final CategorieService categorieService;

    public CategorieController(CategorieService categorieService) {
        this.categorieService = categorieService;
    }

    @PostMapping
    public ResponseEntity<CategorieDTO> createCategorie(@Valid @RequestBody CategorieDTO categorieDTO) {
        CategorieDTO created = categorieService.createCategorie(categorieDTO);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CategorieDTO> updateCategorie(@PathVariable int id, @Valid @RequestBody CategorieDTO categorieDTO) {
        return ResponseEntity.ok(categorieService.updateCategorie(id, categorieDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CategorieDTO> getCategorieById(@PathVariable int id) {
        return ResponseEntity.ok(categorieService.getCategorieById(id));
    }

    @GetMapping
    public ResponseEntity<List<CategorieDTO>> getAllCategories() {
        return ResponseEntity.ok(categorieService.getAllCategories());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategorie(@PathVariable int id) {
        categorieService.deleteCategorie(id);
        return ResponseEntity.noContent().build();
    }

    // Endpoint spécifique pour récupérer par nom (ex: /api/categories/nom/Informatique)
    @GetMapping("/nom/{nom}")
    public ResponseEntity<CategorieDTO> getCategorieByNom(@PathVariable String nom) {
        return ResponseEntity.ok(categorieService.getCategorieByNom(nom));
    }

    // Utile pour une validation rapide côté frontend
    @GetMapping("/check-nom")
    public ResponseEntity<Boolean> checkNomExists(@RequestParam String nom) {
        return ResponseEntity.ok(categorieService.isNomCategorieDejaUtilise(nom));
    }
}