package sn.tdsi.gestionbibliotheque.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.tdsi.gestionbibliotheque.entity.Personnel;
import sn.tdsi.gestionbibliotheque.exception.EntityNotFoundException;
import sn.tdsi.gestionbibliotheque.repository.PersonnelRepository;
import sn.tdsi.gestionbibliotheque.service.PersonnelService;

import java.util.List;
import java.util.Locale;

@Service
@Transactional
@RequiredArgsConstructor
public class PersonnelServiceImpl implements PersonnelService {

    private final PersonnelRepository personnelRepository;
    private final MessageSource messageSource;

    @Override
    public boolean ajouterPersonnel(Personnel personnel) {
        if (personnelRepository.existsByEmail(personnel.getEmail())) {
            throw new RuntimeException(
                    messageSource.getMessage(
                            "personnel.exists",
                            new Object[]{personnel.getEmail()},
                            Locale.getDefault()
                    )
            );
        }
        personnelRepository.save(personnel);
        return true;
    }

    @Override
    public boolean modifierPersonnel(Personnel personnel) {
        Personnel existant = personnelRepository.findById(personnel.getIdPersonnel())
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "personnel.notfound",
                                new Object[]{personnel.getIdPersonnel()},
                                Locale.getDefault()
                        )
                ));

        existant.setNom(personnel.getNom());
        existant.setPrenom(personnel.getPrenom());
        existant.setEmail(personnel.getEmail());
        existant.setMotDePasse(personnel.getMotDePasse());
        existant.setRole(personnel.getRole());

        personnelRepository.save(existant);
        return true;
    }

    @Override
    public boolean supprimerPersonnel(Long idPersonnel) {
        if (!personnelRepository.existsById(idPersonnel)) {
            throw new EntityNotFoundException(
                    messageSource.getMessage(
                            "personnel.notfound",
                            new Object[]{idPersonnel},
                            Locale.getDefault()
                    )
            );
        }
        personnelRepository.deleteById(idPersonnel);
        return true;
    }

    @Override
    public Personnel getPersonnelParId(Long idPersonnel) {
        return personnelRepository.findById(idPersonnel)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "personnel.notfound",
                                new Object[]{idPersonnel},
                                Locale.getDefault()
                        )
                ));
    }

    @Override
    public List<Personnel> getTousLesPersonnels() {
        return personnelRepository.findAll();
    }

    @Override
    public Personnel authentifierPersonnel(String email, String motDePasse) {
        Personnel personnel = personnelRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException(
                        messageSource.getMessage(
                                "personnel.login.invalid",
                                null,
                                Locale.getDefault()
                        )
                ));

        if (!personnel.getMotDePasse().equals(motDePasse)) {
            throw new RuntimeException(
                    messageSource.getMessage(
                            "personnel.login.invalid",
                            null,
                            Locale.getDefault()
                    )
            );
        }
        return personnel;
    }

    @Override
    public List<Personnel> rechercherPersonnels(String critere) {
        return personnelRepository
                .findByNomContainingIgnoreCaseOrPrenomContainingIgnoreCase(critere, critere);
    }

    @Override
    public boolean changerMotDePasse(Long idPersonnel, String ancienMotDePasse, String nouveauMotDePasse) {
        Personnel personnel = personnelRepository.findById(idPersonnel)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "personnel.notfound",
                                new Object[]{idPersonnel},
                                Locale.getDefault()
                        )
                ));

        if (!personnel.getMotDePasse().equals(ancienMotDePasse)) {
            throw new RuntimeException(
                    messageSource.getMessage(
                            "personnel.password.invalid",
                            null,
                            Locale.getDefault()
                    )
            );
        }

        personnel.setMotDePasse(nouveauMotDePasse);
        personnelRepository.save(personnel);
        return true;
    }

    @Override
    public boolean estEmailDejaUtilise(String email) {
        return personnelRepository.existsByEmail(email);
    }
}
