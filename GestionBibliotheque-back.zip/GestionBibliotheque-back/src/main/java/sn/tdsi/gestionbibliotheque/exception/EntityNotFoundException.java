package sn.tdsi.gestionbibliotheque.exception;

public class EntityNotFoundException extends RuntimeException {

     public EntityNotFoundException(String message) {
          super(message);
     }
}
