package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.entity.Emprunt;

import java.util.List;

public interface EmpruntService {

    // Méthodes pour les utilisateurs
    boolean demanderEmprunt(Long idUtilisateur, Long idLivre);

    // Méthodes pour le personnel
    boolean validerEmprunt(Long idEmprunt, Long idPersonnel);
    boolean refuserEmprunt(Long idEmprunt, Long idPersonnel);
    boolean retournerLivre(Long idEmprunt, Long idPersonnel);

    boolean supprimerEmprunt(Long idEmprunt);
    boolean modifierEmprunt(Emprunt emprunt);

    // Méthodes de consultation
    Emprunt getEmpruntParId(Long idEmprunt);
    List<Emprunt> getTousLesEmprunts();
    List<Emprunt> getEmpruntsParUtilisateur(Long idUtilisateur);
    List<Emprunt> getEmpruntsParLivre(Long idLivre);
    List<Emprunt> getEmpruntsEnAttente();
    List<Emprunt> getEmpruntsValides();
    List<Emprunt> getEmpruntsEnRetard();

    boolean estLivreEmprunteActuellement(Long idLivre);
}
