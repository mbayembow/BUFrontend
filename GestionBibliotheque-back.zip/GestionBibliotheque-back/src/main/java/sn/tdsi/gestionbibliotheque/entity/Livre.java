package sn.tdsi.gestionbibliotheque.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "livre")
@AllArgsConstructor
@NoArgsConstructor
public class Livre {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_livre")
    private Long idLivre;

    @Column(name = "titre", nullable = false, length = 255)
    private String titre;

    @Column(name = "reference", nullable = false, length = 100, unique = true)
    private String reference;

    // Enum pour le statut
    public enum Status {
        Disponible, NonDisponible
    }

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private Status status;

    @Column(name = "stock", nullable = false)
    private int stock;

    @Column(name = "isbn", nullable = false, length = 20, unique = true)
    private String isbn;

    @Column(nullable = false)
    private int quantite;

    // Relations avec d'autres entités
    @ManyToOne
    @JoinColumn(name = "id_editeur", nullable = false)
    private Editeur editeur;

    @ManyToOne
    @JoinColumn(name = "id_personnel", nullable = false)
    private Personnel personnel;

    @ManyToOne
    @JoinColumn(name = "id_auteur", nullable = false)
    private Auteur auteur;

    @ManyToOne
    @JoinColumn(name = "id_categorie", nullable = false)
    private Categorie categorie;

    @Column(name = "image_url", length = 255)
    private String imageUrl;


}
