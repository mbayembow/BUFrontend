package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.AuteurDTO;
import sn.tdsi.gestionbibliotheque.entity.Auteur;

@Mapper(componentModel = "spring")
public interface AuteurMapper {
    AuteurDTO toDTO(Auteur auteur);
    Auteur fromDTO(AuteurDTO dto);
}
