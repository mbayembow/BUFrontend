package sn.tdsi.gestionbibliotheque.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.entity.Editeur;
import sn.tdsi.gestionbibliotheque.service.EditeurService;

import java.util.List;

@RestController
@RequestMapping("/api/editeurs")
@CrossOrigin("*")
public class EditeurController {

    private final EditeurService editeurService;

    public EditeurController(EditeurService editeurService) {
        this.editeurService = editeurService;
    }

    @PostMapping
    public ResponseEntity<String> ajouterEditeur(@RequestBody Editeur editeur) {
        boolean success = editeurService.ajouterEditeur(editeur);
        if (success) {
            return new ResponseEntity<>("Éditeur ajouté avec succès.", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Cet éditeur existe déjà (nom déjà utilisé).", HttpStatus.CONFLICT);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> modifierEditeur(@PathVariable Long id, @RequestBody Editeur editeur) {
        editeur.setIdEditeur(id); // On s'assure que l'ID de l'URL est bien celui de l'objet
        boolean success = editeurService.modifierEditeur(editeur);
        if (success) {
            return ResponseEntity.ok("Éditeur mis à jour avec succès.");
        } else {
            return new ResponseEntity<>("Éditeur introuvable pour modification.", HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerEditeur(@PathVariable Long id) {
        boolean success = editeurService.supprimerEditeur(id);
        if (success) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Editeur> getEditeurById(@PathVariable Long id) {
        Editeur editeur = editeurService.getEditeurParId(id);
        if (editeur != null) {
            return ResponseEntity.ok(editeur);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping
    public ResponseEntity<List<Editeur>> getTousLesEditeurs() {
        return ResponseEntity.ok(editeurService.getTousLesEditeurs());
    }
}