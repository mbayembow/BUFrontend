package sn.tdsi.gestionbibliotheque.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.entity.Personnel;
import sn.tdsi.gestionbibliotheque.service.PersonnelService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/personnel")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class PersonnelController {

    private final PersonnelService personnelService;

    // --- CRUD DE BASE ---

    @GetMapping
    public ResponseEntity<List<Personnel>> getAll() {
        return ResponseEntity.ok(personnelService.getTousLesPersonnels());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Personnel> getById(@PathVariable Long id) {
        Personnel p = personnelService.getPersonnelParId(id);
        return p != null ? ResponseEntity.ok(p) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<String> create(@RequestBody Personnel personnel) {
        boolean success = personnelService.ajouterPersonnel(personnel);
        if (success) {
            return new ResponseEntity<>("Personnel créé avec succès.", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Cet email est déjà utilisé.", HttpStatus.CONFLICT);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> update(@PathVariable Long id, @RequestBody Personnel personnel) {
        personnel.setIdPersonnel(id);
        boolean success = personnelService.modifierPersonnel(personnel);
        return success ? ResponseEntity.ok("Mise à jour réussie.") : ResponseEntity.badRequest().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean success = personnelService.supprimerPersonnel(id);
        return success ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    // --- AUTHENTIFICATION & SÉCURITÉ ---

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        String email = credentials.get("email");
        String mdp = credentials.get("motDePasse");

        Personnel p = personnelService.authentifierPersonnel(email, mdp);
        if (p != null) {
            return ResponseEntity.ok(p);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Email ou mot de passe incorrect.");
        }
    }

    @PatchMapping("/{id}/password")
    public ResponseEntity<String> changePassword(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        boolean success = personnelService.changerMotDePasse(
                id,
                body.get("ancienMdp"),
                body.get("nouveauMdp")
        );

        return success ? ResponseEntity.ok("Mot de passe modifié.") : ResponseEntity.badRequest().body("Ancien mot de passe incorrect.");
    }

    // --- RECHERCHE ---

    @GetMapping("/recherche")
    public ResponseEntity<List<Personnel>> search(@RequestParam String critere) {
        return ResponseEntity.ok(personnelService.rechercherPersonnels(critere));
    }
}