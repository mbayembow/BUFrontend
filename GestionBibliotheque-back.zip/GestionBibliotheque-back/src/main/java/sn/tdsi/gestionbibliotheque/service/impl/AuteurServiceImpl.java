package sn.tdsi.gestionbibliotheque.service.impl;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.tdsi.gestionbibliotheque.dto.AuteurDTO;
import sn.tdsi.gestionbibliotheque.entity.Auteur;
import sn.tdsi.gestionbibliotheque.exception.EntityNotFoundException;
import sn.tdsi.gestionbibliotheque.mapper.AuteurMapper;
import sn.tdsi.gestionbibliotheque.repository.AuteurRepository;
import sn.tdsi.gestionbibliotheque.service.AuteurService;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static sn.tdsi.gestionbibliotheque.constant.Messages.AUTEUR_NOT_FOUND;

@Service
@Transactional
public class AuteurServiceImpl implements AuteurService {

    private final AuteurRepository auteurRepository;
    private final AuteurMapper auteurMapper;
    private final MessageSource messageSource;

    public AuteurServiceImpl(AuteurRepository auteurRepository, AuteurMapper auteurMapper, MessageSource messageSource) {
        this.auteurRepository = auteurRepository;
        this.auteurMapper = auteurMapper;
        this.messageSource = messageSource;
    }

    @Override
    public AuteurDTO createAuteur(AuteurDTO dto) {
        // Si nécessaire, tu peux ajouter la vérification doublon ici
        Auteur auteur = auteurMapper.fromDTO(dto);
        auteur = auteurRepository.save(auteur);
        return auteurMapper.toDTO(auteur);
    }

    @Override
    public AuteurDTO updateAuteur(Long id, AuteurDTO dto) {
        Auteur auteur = auteurRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage( AUTEUR_NOT_FOUND, new Object[]{id}, Locale.getDefault())
                ));

        auteur.setNom(dto.getNom());
        auteur.setPrenom(dto.getPrenom());
        auteur.setNationalite(dto.getNationalite());

        auteur = auteurRepository.save(auteur);
        return auteurMapper.toDTO(auteur);
    }

    @Override
    public void deleteAuteur(Long id) {
        if (!auteurRepository.existsById(id)) {
            throw new EntityNotFoundException(
                    messageSource.getMessage(AUTEUR_NOT_FOUND, new Object[]{id}, Locale.getDefault())
            );
        }
        auteurRepository.deleteById(id);
    }

    @Override
    public AuteurDTO getAuteurById(Long id) {
        Auteur auteur = auteurRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(AUTEUR_NOT_FOUND, new Object[]{id}, Locale.getDefault())
                ));
        return auteurMapper.toDTO(auteur);
    }

    @Override
    public List<AuteurDTO> getAllAuteurs() {
        return auteurRepository.findAll().stream()
                .map(auteurMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<AuteurDTO> searchAuteurs(String critere) {
        String critereLower = critere.toLowerCase();
        return auteurRepository.findAll().stream()
                .filter(a -> a.getNom().toLowerCase().contains(critereLower)
                        || a.getPrenom().toLowerCase().contains(critereLower))
                .map(auteurMapper::toDTO)
                .collect(Collectors.toList());
    }
}
