package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.EcrireDTO;
import sn.tdsi.gestionbibliotheque.entity.Ecrire;

@Mapper(componentModel = "spring")
public interface EcrireMapper {
    EcrireDTO toDTO(Ecrire ecrire);
    Ecrire fromDTO(EcrireDTO dto);
}
