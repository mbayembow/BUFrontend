package sn.tdsi.gestionbibliotheque.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.tdsi.gestionbibliotheque.entity.Emprunt;
import sn.tdsi.gestionbibliotheque.entity.Livre;
import sn.tdsi.gestionbibliotheque.entity.Personnel;
import sn.tdsi.gestionbibliotheque.entity.Utilisateur;
import sn.tdsi.gestionbibliotheque.exception.EntityNotFoundException;
import sn.tdsi.gestionbibliotheque.repository.EmpruntRepository;
import sn.tdsi.gestionbibliotheque.repository.LivreRepository;
import sn.tdsi.gestionbibliotheque.repository.PersonnelRepository;
import sn.tdsi.gestionbibliotheque.repository.UtilisateurRepository;
import sn.tdsi.gestionbibliotheque.service.EmpruntService;

import java.time.LocalDate;
import java.util.List;

@Service
@Transactional
public class EmpruntServiceImpl implements EmpruntService {

    private static final String EMPRUNT_NOT_FOUND = "Emprunt introuvable";
    private static final String LIVRE_NOT_FOUND = "Livre introuvable";
    private static final String UTILISATEUR_NOT_FOUND = "Utilisateur introuvable";
    private static final String PERSONNEL_NOT_FOUND = "Personnel introuvable";

    private final EmpruntRepository empruntRepository;
    private final LivreRepository livreRepository;
    private final UtilisateurRepository utilisateurRepository;
    private final PersonnelRepository personnelRepository;

    public EmpruntServiceImpl(
            EmpruntRepository empruntRepository,
            LivreRepository livreRepository,
            UtilisateurRepository utilisateurRepository,
            PersonnelRepository personnelRepository
    ) {
        this.empruntRepository = empruntRepository;
        this.livreRepository = livreRepository;
        this.utilisateurRepository = utilisateurRepository;
        this.personnelRepository = personnelRepository;
    }

    @Override
    public boolean demanderEmprunt(Long idUtilisateur, Long idLivre) {
        Utilisateur utilisateur = utilisateurRepository.findById(idUtilisateur)
                .orElseThrow(() -> new EntityNotFoundException(UTILISATEUR_NOT_FOUND));

        Livre livre = livreRepository.findById(idLivre)
                .orElseThrow(() -> new EntityNotFoundException(LIVRE_NOT_FOUND));

        if (estLivreEmprunteActuellement(idLivre)) {
            return false;
        }

        Emprunt emprunt = new Emprunt();
        emprunt.setUtilisateur(utilisateur);
        emprunt.setLivre(livre);
        emprunt.setDateDemande(LocalDate.now());
        emprunt.setStatut(Emprunt.Statut.En_attente);

        empruntRepository.save(emprunt);
        return true;
    }

    @Override
    public boolean validerEmprunt(Long idEmprunt, Long idPersonnel) {
        Emprunt emprunt = empruntRepository.findById(idEmprunt)
                .orElseThrow(() -> new EntityNotFoundException(EMPRUNT_NOT_FOUND));

        Personnel personnel = personnelRepository.findById(idPersonnel)
                .orElseThrow(() -> new EntityNotFoundException(PERSONNEL_NOT_FOUND));

        emprunt.setStatut(Emprunt.Statut.Valide);
        emprunt.setDateEmprunt(LocalDate.now());
        emprunt.setDateRetour(LocalDate.now().plusWeeks(2));
        emprunt.setPersonnel(personnel);

        empruntRepository.save(emprunt);
        return true;
    }

    @Override
    public boolean refuserEmprunt(Long idEmprunt, Long idPersonnel) {
        Emprunt emprunt = empruntRepository.findById(idEmprunt)
                .orElseThrow(() -> new EntityNotFoundException(EMPRUNT_NOT_FOUND));

        Personnel personnel = personnelRepository.findById(idPersonnel)
                .orElseThrow(() -> new EntityNotFoundException(PERSONNEL_NOT_FOUND));

        emprunt.setStatut(Emprunt.Statut.Refuse);
        emprunt.setPersonnel(personnel);

        empruntRepository.save(emprunt);
        return true;
    }

    @Override
    public boolean retournerLivre(Long idEmprunt, Long idPersonnel) {
        Emprunt emprunt = empruntRepository.findById(idEmprunt)
                .orElseThrow(() -> new EntityNotFoundException(EMPRUNT_NOT_FOUND));

        Personnel personnel = personnelRepository.findById(idPersonnel)
                .orElseThrow(() -> new EntityNotFoundException(PERSONNEL_NOT_FOUND));

        emprunt.setStatut(Emprunt.Statut.Retourne);
        emprunt.setPersonnel(personnel);

        empruntRepository.save(emprunt);
        return true;
    }

    @Override
    public boolean supprimerEmprunt(Long idEmprunt) {
        if (!empruntRepository.existsById(idEmprunt)) {
            throw new EntityNotFoundException(EMPRUNT_NOT_FOUND);
        }
        empruntRepository.deleteById(idEmprunt);
        return true;
    }

    @Override
    public boolean modifierEmprunt(Emprunt emprunt) {
        if (!empruntRepository.existsById(emprunt.getIdEmprunt())) {
            throw new EntityNotFoundException(EMPRUNT_NOT_FOUND);
        }
        empruntRepository.save(emprunt);
        return true;
    }

    @Override
    public Emprunt getEmpruntParId(Long idEmprunt) {
        return empruntRepository.findById(idEmprunt)
                .orElseThrow(() -> new EntityNotFoundException(EMPRUNT_NOT_FOUND));
    }

    @Override
    public List<Emprunt> getTousLesEmprunts() {
        return empruntRepository.findAll();
    }

    @Override
    public List<Emprunt> getEmpruntsParUtilisateur(Long idUtilisateur) {
        // Appelle la méthode corrigée du repository
        return empruntRepository.findByUtilisateur_IdUtilisateur(idUtilisateur);
    }

    @Override
    public List<Emprunt> getEmpruntsParLivre(Long idLivre) {
        // Appelle la méthode corrigée du repository
        return empruntRepository.findByLivre_IdLivre(idLivre);
    }

    @Override
    public List<Emprunt> getEmpruntsEnAttente() {
        return empruntRepository.findByStatut(Emprunt.Statut.En_attente);
    }

    @Override
    public List<Emprunt> getEmpruntsValides() {
        return empruntRepository.findByStatut(Emprunt.Statut.Valide);
    }

    @Override
    public List<Emprunt> getEmpruntsEnRetard() {
        return empruntRepository.findAll().stream()
                .filter(Emprunt::isEnRetard)
                .toList();
    }

    @Override
    public boolean estLivreEmprunteActuellement(Long idLivre) {
        // Appelle la méthode corrigée du repository
        return empruntRepository.findByLivre_IdLivre(idLivre).stream()
                .anyMatch(e ->
                        e.getStatut() == Emprunt.Statut.Valide
                                || e.getStatut() == Emprunt.Statut.En_attente
                );
    }
}