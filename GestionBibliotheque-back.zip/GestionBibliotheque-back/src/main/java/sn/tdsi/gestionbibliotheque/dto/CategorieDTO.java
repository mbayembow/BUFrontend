package sn.tdsi.gestionbibliotheque.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategorieDTO {

    private int idCategorie;

    @NotBlank(message = "Le nom de la catégorie est obligatoire")
    private String nom;

    @NotBlank(message = "La description de la catégorie est obligatoire")
    private String description;
}
