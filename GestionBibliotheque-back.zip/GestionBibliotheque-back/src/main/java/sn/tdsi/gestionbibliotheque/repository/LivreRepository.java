package sn.tdsi.gestionbibliotheque.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sn.tdsi.gestionbibliotheque.entity.Livre;

import java.util.List;

@Repository
public interface LivreRepository extends JpaRepository<Livre, Long> {

    List<Livre> findByTitreContainingIgnoreCase(String titre);
    List<Livre> findByIsbnContaining(String isbn);
}
