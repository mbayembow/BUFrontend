package sn.tdsi.gestionbibliotheque.service.impl;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.tdsi.gestionbibliotheque.entity.Livre;
import sn.tdsi.gestionbibliotheque.exception.EntityNotFoundException;
import sn.tdsi.gestionbibliotheque.repository.LivreRepository;
import sn.tdsi.gestionbibliotheque.service.LivreService;

import java.util.List;
import java.util.Locale;

@Service
@Transactional
public class LivreServiceImpl implements LivreService {

    private final LivreRepository livreRepository;
    private final MessageSource messageSource;

    public LivreServiceImpl(LivreRepository livreRepository, MessageSource messageSource) {
        this.livreRepository = livreRepository;
        this.messageSource = messageSource;
    }

    // ✅ CREATE
    @Override
    public Livre ajouterLivre(Livre livre) {
        return livreRepository.save(livre);
    }

    // ✅ UPDATE
    @Override
    public Livre modifierLivre(Livre livre) {

        Livre existingLivre = livreRepository.findById(livre.getIdLivre())
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage("livre.notfound",
                                new Object[]{livre.getIdLivre()},
                                Locale.getDefault())
                ));

        existingLivre.setTitre(livre.getTitre());
        existingLivre.setAuteur(livre.getAuteur());
        existingLivre.setCategorie(livre.getCategorie());
        existingLivre.setEditeur(livre.getEditeur());
        existingLivre.setQuantite(livre.getQuantite());

        return livreRepository.save(existingLivre);
    }

    // ✅ DELETE
    @Override
    public Void supprimerLivre(Long idLivre) {

        if (!livreRepository.existsById(idLivre)) {
            throw new EntityNotFoundException(
                    messageSource.getMessage("livre.notfound",
                            new Object[]{idLivre},
                            Locale.getDefault())
            );
        }

        livreRepository.deleteById(idLivre);
        return null;
    }

    // ✅ GET BY ID
    @Override
    public Livre getLivreParId(Long idLivre) {
        return livreRepository.findById(idLivre)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage("livre.notfound",
                                new Object[]{idLivre},
                                Locale.getDefault())
                ));
    }

    // ✅ GET ALL
    @Override
    public List<Livre> getTousLesLivres() {
        return livreRepository.findAll();
    }

    // ✅ SEARCH
    @Override
    public List<Livre> rechercherLivres(String critere) {

        String critereLower = critere.toLowerCase();

        return livreRepository.findAll().stream()
                .filter(l ->
                        (l.getTitre() != null &&
                                l.getTitre().toLowerCase().contains(critereLower))
                                ||
                                (l.getAuteur() != null &&
                                        (
                                                (l.getAuteur().getNom() != null &&
                                                        l.getAuteur().getNom().toLowerCase().contains(critereLower))
                                                        ||
                                                        (l.getAuteur().getPrenom() != null &&
                                                                l.getAuteur().getPrenom().toLowerCase().contains(critereLower))
                                        )
                                )
                )
                .toList();
    }

    // ✅ CHECK AVAILABILITY
    @Override
    public boolean estLivreDisponible(Long idLivre) {

        Livre livre = livreRepository.findById(idLivre)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage("livre.notfound",
                                new Object[]{idLivre},
                                Locale.getDefault())
                ));

        return livre.getQuantite() > 0;
    }

    // ✅ UPDATE STOCK
    @Override
    public Livre mettreAJourStockLivre(Long idLivre, int nouvelleQuantite) {

        Livre livre = livreRepository.findById(idLivre)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage("livre.notfound",
                                new Object[]{idLivre},
                                Locale.getDefault())
                ));

        livre.setQuantite(nouvelleQuantite);

        return livreRepository.save(livre);
    }
}
