package sn.tdsi.gestionbibliotheque.service.impl;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.tdsi.gestionbibliotheque.entity.Auteur;
import sn.tdsi.gestionbibliotheque.entity.Ecrire;
import sn.tdsi.gestionbibliotheque.entity.Livre;
import sn.tdsi.gestionbibliotheque.repository.AuteurRepository;
import sn.tdsi.gestionbibliotheque.repository.EcrireRepository;
import sn.tdsi.gestionbibliotheque.repository.LivreRepository;
import sn.tdsi.gestionbibliotheque.service.EcrireService;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static sn.tdsi.gestionbibliotheque.constant.Messages.AUTEUR_NOT_FOUND;
import static sn.tdsi.gestionbibliotheque.constant.Messages.LIVRE_NOT_FOUND;

@Service
@Transactional
public class EcrireServiceImpl implements EcrireService {

    private final EcrireRepository ecrireRepository;
    private final AuteurRepository auteurRepository;
    private final LivreRepository livreRepository;
    private final MessageSource messageSource;

    public EcrireServiceImpl(EcrireRepository ecrireRepository,
                             AuteurRepository auteurRepository,
                             LivreRepository livreRepository,
                             MessageSource messageSource) {
        this.ecrireRepository = ecrireRepository;
        this.auteurRepository = auteurRepository;
        this.livreRepository = livreRepository;
        this.messageSource = messageSource;
    }

    @Override
    public boolean associerAuteurLivre(Long idAuteur, Long idLivre) {
        // 1. Vérification doublon
        if (ecrireRepository.existsByAuteur_IdAuteurAndLivre_IdLivre(idAuteur, idLivre)) {
            return false;
        }

        // 2. Récupération Auteur avec la clé EXACTE du fichier .properties
        Auteur auteur = auteurRepository.findById(idAuteur)
                .orElseThrow(() -> new RuntimeException(
                        messageSource.getMessage("auteur.notfound", new Object[]{idAuteur}, Locale.getDefault())
                ));

        // 3. Récupération Livre avec la clé EXACTE du fichier .properties
        Livre livre = livreRepository.findById(idLivre)
                .orElseThrow(() -> new RuntimeException(
                        messageSource.getMessage("livre.notfound", new Object[]{idLivre}, Locale.getDefault())
                ));

        // 4. Sauvegarde
        ecrireRepository.save(new Ecrire(auteur, livre));
        return true;
    }

    @Override
    public boolean dissocierAuteurLivre(Long idAuteur, Long idLivre) {
        return ecrireRepository
                .findByAuteur_IdAuteurAndLivre_IdLivre(idAuteur, idLivre)
                .map(e -> {
                    ecrireRepository.delete(e);
                    return true;
                })
                .orElse(false);
    }

    @Override
    public List<Long> getIdsAuteursParLivre(Long idLivre) {
        return ecrireRepository.findByLivre_IdLivre(idLivre)
                .stream()
                .map(e -> e.getAuteur().getIdAuteur())
                .collect(Collectors.toList());
    }

    @Override
    public List<Long> getIdsLivresParAuteur(Long idAuteur) {
        return ecrireRepository.findByAuteur_IdAuteur(idAuteur)
                .stream()
                .map(e -> e.getLivre().getIdLivre())
                .collect(Collectors.toList());
    }
}