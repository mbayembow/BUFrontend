package sn.tdsi.gestionbibliotheque.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.entity.Emprunt;
import sn.tdsi.gestionbibliotheque.service.EmpruntService;

import java.util.List;

@RestController
@RequestMapping("/api/emprunts")
@CrossOrigin("*")
public class EmpruntController {

    private final EmpruntService empruntService;

    public EmpruntController(EmpruntService empruntService) {
        this.empruntService = empruntService;
    }

    // --- ACTIONS MÉTIER ---

    @PostMapping("/demander")
    public ResponseEntity<String> demanderEmprunt(@RequestParam Long idUtilisateur, @RequestParam Long idLivre) {
        boolean success = empruntService.demanderEmprunt(idUtilisateur, idLivre);
        if (success) {
            return new ResponseEntity<>("Demande d'emprunt enregistrée.", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Ce livre est déjà réservé ou emprunté.", HttpStatus.CONFLICT);
        }
    }

    @PatchMapping("/{id}/valider")
    public ResponseEntity<Void> validerEmprunt(@PathVariable Long id, @RequestParam Long idPersonnel) {
        empruntService.validerEmprunt(id, idPersonnel);
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/{id}/refuser")
    public ResponseEntity<Void> refuserEmprunt(@PathVariable Long id, @RequestParam Long idPersonnel) {
        empruntService.refuserEmprunt(id, idPersonnel);
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/{id}/retourner")
    public ResponseEntity<Void> retournerLivre(@PathVariable Long id, @RequestParam Long idPersonnel) {
        empruntService.retournerLivre(id, idPersonnel);
        return ResponseEntity.ok().build();
    }

    // --- CONSULTATIONS ---

    @GetMapping
    public ResponseEntity<List<Emprunt>> getAll() {
        return ResponseEntity.ok(empruntService.getTousLesEmprunts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Emprunt> getById(@PathVariable Long id) {
        return ResponseEntity.ok(empruntService.getEmpruntParId(id));
    }

    @GetMapping("/en-attente")
    public ResponseEntity<List<Emprunt>> getEnAttente() {
        return ResponseEntity.ok(empruntService.getEmpruntsEnAttente());
    }

    @GetMapping("/en-retard")
    public ResponseEntity<List<Emprunt>> getEnRetard() {
        return ResponseEntity.ok(empruntService.getEmpruntsEnRetard());
    }

    @GetMapping("/utilisateur/{idUtilisateur}")
    public ResponseEntity<List<Emprunt>> getByUtilisateur(@PathVariable Long idUtilisateur) {
        return ResponseEntity.ok(empruntService.getEmpruntsParUtilisateur(idUtilisateur));
    }

    // --- ADMINISTRATION ---

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        empruntService.supprimerEmprunt(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> update(@PathVariable Long id, @RequestBody Emprunt emprunt) {
        emprunt.setIdEmprunt(id);
        empruntService.modifierEmprunt(emprunt);
        return ResponseEntity.ok().build();
    }
}