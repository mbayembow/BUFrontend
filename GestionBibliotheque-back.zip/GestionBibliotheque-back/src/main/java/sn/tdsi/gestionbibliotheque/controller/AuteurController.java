package sn.tdsi.gestionbibliotheque.controller;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.dto.AuteurDTO;
import sn.tdsi.gestionbibliotheque.service.AuteurService;

import java.util.List;

@RestController
@RequestMapping("/api/auteurs")
@CrossOrigin("*")
public class AuteurController {

    private final AuteurService auteurService;

    // Injection par constructeur (recommandé par Spring)
    public AuteurController(AuteurService auteurService) {
        this.auteurService = auteurService;
    }

    @PostMapping
    public ResponseEntity<AuteurDTO> createAuteur(@Valid @RequestBody AuteurDTO auteurDTO) {
        AuteurDTO created = auteurService.createAuteur(auteurDTO);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AuteurDTO> updateAuteur(@PathVariable Long id, @Valid @RequestBody AuteurDTO auteurDTO) {
        return ResponseEntity.ok(auteurService.updateAuteur(id, auteurDTO));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AuteurDTO> getAuteurById(@PathVariable Long id) {
        return ResponseEntity.ok(auteurService.getAuteurById(id));
    }

    @GetMapping
    public ResponseEntity<List<AuteurDTO>> getAllAuteurs() {
        return ResponseEntity.ok(auteurService.getAllAuteurs());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAuteur(@PathVariable Long id) {
        auteurService.deleteAuteur(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<AuteurDTO>> searchAuteurs(@RequestParam String critere) {
        return ResponseEntity.ok(auteurService.searchAuteurs(critere));
    }
}