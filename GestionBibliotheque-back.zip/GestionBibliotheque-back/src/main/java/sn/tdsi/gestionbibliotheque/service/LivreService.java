package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.entity.Livre;
import java.util.List;

public interface LivreService {

    Livre  ajouterLivre(Livre livre);
    Livre modifierLivre(Livre livre);
    Void supprimerLivre(Long idLivre);

    Livre getLivreParId(Long idLivre);
    List<Livre> getTousLesLivres();

    List<Livre> rechercherLivres(String critere);
    boolean estLivreDisponible(Long idLivre);
    Livre mettreAJourStockLivre(Long idLivre, int nouvelleQuantite);
}
