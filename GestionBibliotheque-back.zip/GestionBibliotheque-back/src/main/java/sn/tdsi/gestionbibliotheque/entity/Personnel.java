package sn.tdsi.gestionbibliotheque.entity;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "personnel")
@NoArgsConstructor
@AllArgsConstructor
public class Personnel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_personnel")
    private Long idPersonnel;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false)
    private String prenom;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(name = "num_tel")
    private String numTel;

    @Column(nullable = false)
    private String motDePasse;

    @Column(nullable = false)
    private String role;

}
