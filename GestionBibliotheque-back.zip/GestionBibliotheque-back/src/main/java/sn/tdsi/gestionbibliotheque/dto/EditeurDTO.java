package sn.tdsi.gestionbibliotheque.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EditeurDTO {

    private int idEditeur;

    @NotBlank(message = "Le nom de l'éditeur ne peut pas être vide")
    private String nom;

    @NotNull(message = "La date de création de l'éditeur est obligatoire")
    private Date date;
}
