package sn.tdsi.gestionbibliotheque.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Entity
@Table(name = "editeur")
@AllArgsConstructor
@NoArgsConstructor
public class Editeur {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_editeur")
    private Long idEditeur;

    @Column(name = "nom", nullable = false, length = 150, unique = true)
    private String nom;

    @Column(name = "date_creation")
    private LocalDate date; // Utilisation de java.time.LocalDate
}
