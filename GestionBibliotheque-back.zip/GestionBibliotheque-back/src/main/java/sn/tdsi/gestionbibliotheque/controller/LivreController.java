package sn.tdsi.gestionbibliotheque.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.entity.Livre;
import sn.tdsi.gestionbibliotheque.service.LivreService;

import java.util.List;

@RestController
@RequestMapping("/api/livres")
@CrossOrigin("*")
public class LivreController {

    private final LivreService livreService;

    public LivreController(LivreService livreService) {
        this.livreService = livreService;
    }

    // ✅ GET ALL
    @GetMapping
    public ResponseEntity<List<Livre>> getAllLivres() {
        return ResponseEntity.ok(livreService.getTousLesLivres());
    }

    // ✅ GET BY ID
    @GetMapping("/{id}")
    public ResponseEntity<Livre> getLivreById(@PathVariable Long id) {
        Livre livre = livreService.getLivreParId(id);
        return ResponseEntity.ok(livre);
    }

    // ✅ CREATE
    @PostMapping
    public ResponseEntity<Livre> ajouterLivre(@RequestBody Livre livre) {

        Livre livreCree = livreService.ajouterLivre(livre);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(livreCree);
    }

    // ✅ UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<Livre> modifierLivre(@PathVariable Long id,
                                               @RequestBody Livre livre) {

        livre.setIdLivre(id);
        Livre livreModifie = livreService.modifierLivre(livre);

        return ResponseEntity.ok(livreModifie);
    }

    // ✅ DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> supprimerLivre(@PathVariable Long id) {

        livreService.supprimerLivre(id);

        return ResponseEntity.noContent().build();
    }
    // ✅ SEARCH
    @GetMapping("/recherche")
    public ResponseEntity<List<Livre>> rechercher(@RequestParam String critere) {

        return ResponseEntity.ok(livreService.rechercherLivres(critere));
    }
    // ✅ CHECK AVAILABILITY
    @GetMapping("/{id}/disponibilite")
    public ResponseEntity<Boolean> verifierDisponibilite(@PathVariable Long id) {

        return ResponseEntity.ok(livreService.estLivreDisponible(id));
    }

    // ✅ UPDATE STOCK
    @PatchMapping("/{id}/stock")
    public ResponseEntity<Livre> mettreAJourStock(@PathVariable Long id,
                                                  @RequestParam int quantite) {

        Livre livre = livreService.mettreAJourStockLivre(id, quantite);

        return ResponseEntity.ok(livre);
    }
}
