package sn.tdsi.gestionbibliotheque.entity;

import jakarta.persistence.*;
import lombok.*;

@Data
@Entity
@Table(name = "utilisateur")
@NoArgsConstructor
@AllArgsConstructor
public class Utilisateur {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_utilisateur")
    private Long idUtilisateur;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false)
    private String prenom;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(name = "num_tel")
    private String numTel;

    @Column(nullable = false)
    private String motDePasse;

    @Column(unique = true)
    private String nin;

    @Column(nullable = false)
    private String role;

    @Column(name = "nom_utilisateur", unique = true)
    private String nomUtilisateur;
}
