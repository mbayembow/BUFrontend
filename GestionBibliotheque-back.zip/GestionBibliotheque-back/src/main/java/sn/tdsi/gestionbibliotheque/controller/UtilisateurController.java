package sn.tdsi.gestionbibliotheque.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.tdsi.gestionbibliotheque.entity.Utilisateur;
import sn.tdsi.gestionbibliotheque.service.UtilisateurService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/utilisateurs")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class UtilisateurController {

    private final UtilisateurService utilisateurService;

    // --- GESTION DES COMPTES ---

    @PostMapping("/inscription")
    public ResponseEntity<String> inscrire(@RequestBody Utilisateur utilisateur) {
        boolean success = utilisateurService.inscrireUtilisateur(utilisateur);
        if (success) {
            return new ResponseEntity<>("Inscription réussie.", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Cet email est déjà associé à un compte.", HttpStatus.CONFLICT);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
        Utilisateur u = utilisateurService.authentifierUtilisateur(
                credentials.get("email"),
                credentials.get("motDePasse")
        );

        if (u != null) {
            return ResponseEntity.ok(u);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Identifiants invalides.");
        }
    }

    @PatchMapping("/{id}/password")
    public ResponseEntity<String> updatePassword(
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {

        boolean success = utilisateurService.changerMotDePasse(
                id,
                body.get("ancienMdp"),
                body.get("nouveauMdp")
        );
        return success ? ResponseEntity.ok("Mot de passe mis à jour.") :
                ResponseEntity.badRequest().body("Échec du changement de mot de passe.");
    }

    // --- CONSULTATION ET RECHERCHE ---

    @GetMapping
    public ResponseEntity<List<Utilisateur>> getAll() {
        return ResponseEntity.ok(utilisateurService.getTousLesUtilisateurs());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Utilisateur> getById(@PathVariable Long id) {
        Utilisateur u = utilisateurService.getUtilisateurParId(id);
        return u != null ? ResponseEntity.ok(u) : ResponseEntity.notFound().build();
    }

    @GetMapping("/recherche")
    public ResponseEntity<List<Utilisateur>> search(@RequestParam String critere) {
        return ResponseEntity.ok(utilisateurService.rechercherUtilisateurs(critere));
    }

    // --- MODIFICATION ET SUPPRESSION ---

    @PutMapping("/{id}")
    public ResponseEntity<String> update(@PathVariable Long id, @RequestBody Utilisateur utilisateur) {
        utilisateur.setIdUtilisateur(id);
        boolean success = utilisateurService.modifierUtilisateur(utilisateur);
        return success ? ResponseEntity.ok("Profil mis à jour.") : ResponseEntity.badRequest().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        boolean success = utilisateurService.supprimerUtilisateur(id);
        return success ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}