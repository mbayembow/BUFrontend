package sn.tdsi.gestionbibliotheque.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@RestControllerAdvice
public class APIExceptionHandler {

    /* ===================== RequestException ===================== */
    @ExceptionHandler(RequestException.class)
    public ResponseEntity<APIException> handleRequestException(RequestException e) {
        return buildResponse(e.getMessage(), e.getStatus());
    }

    /* ===================== EntityNotFoundException ===================== */
    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<APIException> handleEntityNotFoundException(EntityNotFoundException e) {
        return buildResponse(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    /* ===================== Validation Errors ===================== */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<APIException> handleValidationException(MethodArgumentNotValidException e) {

        String message = e.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> error.getField() + " : " + error.getDefaultMessage())
                .collect(Collectors.joining(", "));

        return buildResponse(message, HttpStatus.BAD_REQUEST);
    }

    /* ===================== Number Format ===================== */
    @ExceptionHandler(NumberFormatException.class)
    public ResponseEntity<APIException> handleNumberFormatException(NumberFormatException e) {
        return buildResponse("Invalid number format", HttpStatus.BAD_REQUEST);
    }

    /* ===================== Global Exception (sécurité) ===================== */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<APIException> handleGlobalException(Exception e) {
        return buildResponse(
                "An unexpected error occurred",
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }

    /* ===================== Méthode utilitaire ===================== */
    private ResponseEntity<APIException> buildResponse(String message, HttpStatus status) {
        APIException apiException = new APIException(
                message,
                status,
                LocalDateTime.now()
        );
        return new ResponseEntity<>(apiException, status);
    }
}
