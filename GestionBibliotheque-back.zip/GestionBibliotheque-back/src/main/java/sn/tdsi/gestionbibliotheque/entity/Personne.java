package sn.tdsi.gestionbibliotheque.entity;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@MappedSuperclass
@AllArgsConstructor
@NoArgsConstructor
public abstract class Personne {

    @Column(name = "nom", nullable = false, length = 100)
    protected String nom;

    @Column(name = "prenom", nullable = false, length = 100)
    protected String prenom;

    @Column(name = "email", nullable = false, length = 150, unique = true)
    protected String email;

    @Column(name = "num_tel", nullable = false, length = 20)
    protected String num_tel;

    @Column(name = "mot_de_passe", nullable = false, length = 255)
    protected String motDePasse;
}
