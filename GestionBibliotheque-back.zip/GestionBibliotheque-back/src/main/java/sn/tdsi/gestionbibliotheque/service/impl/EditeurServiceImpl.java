package sn.tdsi.gestionbibliotheque.service.impl;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.tdsi.gestionbibliotheque.entity.Editeur;
import sn.tdsi.gestionbibliotheque.exception.EntityNotFoundException;
import sn.tdsi.gestionbibliotheque.repository.EditeurRepository;
import sn.tdsi.gestionbibliotheque.service.EditeurService;

import java.util.List;
import java.util.Locale;

@Service
@Transactional
public class EditeurServiceImpl implements EditeurService {

    private final EditeurRepository editeurRepository;
    private final MessageSource messageSource;

    public EditeurServiceImpl(EditeurRepository editeurRepository,
                              MessageSource messageSource) {
        this.editeurRepository = editeurRepository;
        this.messageSource = messageSource;
    }

    @Override
    public boolean ajouterEditeur(Editeur editeur) {
        if (editeurRepository.findByNom(editeur.getNom()).isPresent()) {
            throw new RuntimeException(
                    messageSource.getMessage(
                            "editeur.exists",
                            new Object[]{editeur.getNom()},
                            Locale.getDefault()
                    )
            );
        }
        editeurRepository.save(editeur);
        return true;
    }

    @Override
    public boolean modifierEditeur(Editeur editeur) {
        Editeur existant = editeurRepository.findById(editeur.getIdEditeur())
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "editeur.notfound",
                                new Object[]{editeur.getIdEditeur()},
                                Locale.getDefault()
                        )
                ));

        existant.setNom(editeur.getNom());
        existant.setDate(editeur.getDate());

        editeurRepository.save(existant);
        return true;
    }

    @Override
    public boolean supprimerEditeur(Long idEditeur) {
        if (!editeurRepository.existsById(idEditeur)) {
            throw new EntityNotFoundException(
                    messageSource.getMessage(
                            "editeur.notfound",
                            new Object[]{idEditeur},
                            Locale.getDefault()
                    )
            );
        }
        editeurRepository.deleteById(idEditeur);
        return true;
    }

    @Override
    public Editeur getEditeurParId(Long idEditeur) {
        return editeurRepository.findById(idEditeur)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(
                                "editeur.notfound",
                                new Object[]{idEditeur},
                                Locale.getDefault()
                        )
                ));
    }

    @Override
    public List<Editeur> getTousLesEditeurs() {
        return editeurRepository.findAll();
    }
}
