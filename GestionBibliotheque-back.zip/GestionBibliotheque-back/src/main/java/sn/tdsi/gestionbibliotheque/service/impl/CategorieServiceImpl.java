package sn.tdsi.gestionbibliotheque.service.impl;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import sn.tdsi.gestionbibliotheque.dto.CategorieDTO;
import sn.tdsi.gestionbibliotheque.entity.Categorie;
import sn.tdsi.gestionbibliotheque.exception.EntityNotFoundException;
import sn.tdsi.gestionbibliotheque.mapper.CategorieMapper;
import sn.tdsi.gestionbibliotheque.repository.CategorieRepository;
import sn.tdsi.gestionbibliotheque.service.CategorieService;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import static sn.tdsi.gestionbibliotheque.constant.Messages.CATEGORIE_EXISTS;
import static sn.tdsi.gestionbibliotheque.constant.Messages.CATEGORIE_NOT_FOUND;

@Service
public class CategorieServiceImpl implements CategorieService {

    private final CategorieRepository categorieRepository;
    private final CategorieMapper categorieMapper;
    private final MessageSource messageSource; // Injection de MessageSource

    public CategorieServiceImpl(CategorieRepository categorieRepository,
                                CategorieMapper categorieMapper,
                                MessageSource messageSource) {
        this.categorieRepository = categorieRepository;
        this.categorieMapper = categorieMapper;
        this.messageSource = messageSource;
    }

    @Override
    public CategorieDTO createCategorie(CategorieDTO dto) {
        if (isNomCategorieDejaUtilise(dto.getNom())) {
            throw new IllegalArgumentException(
                    messageSource.getMessage(CATEGORIE_EXISTS, new Object[]{dto.getNom()}, Locale.getDefault())
            );
        }
        Categorie categorie = categorieMapper.fromDTO(dto);
        categorie = categorieRepository.save(categorie);
        return categorieMapper.toDTO(categorie);
    }

    @Override
    public CategorieDTO updateCategorie(int id, CategorieDTO dto) {
        Categorie categorie = categorieRepository.findById((long) id)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage("categorie.notfound", new Object[]{id}, Locale.getDefault())
                ));

        if (!categorie.getNom().equals(dto.getNom()) && isNomCategorieDejaUtilise(dto.getNom())) {
            throw new IllegalArgumentException(
                    messageSource.getMessage(CATEGORIE_EXISTS, new Object[]{dto.getNom()}, Locale.getDefault())
            );
        }

        categorie.setNom(dto.getNom());
        categorie.setDescription(dto.getDescription());
        categorie = categorieRepository.save(categorie);
        return categorieMapper.toDTO(categorie);
    }

    @Override
    public void deleteCategorie(int id) {
        if (!categorieRepository.existsById((long) id)) {
            throw new EntityNotFoundException(
                    messageSource.getMessage(CATEGORIE_NOT_FOUND, new Object[]{id}, Locale.getDefault())
            );
        }
        categorieRepository.deleteById((long) id);
    }

    @Override
    public CategorieDTO getCategorieById(int id) {
        Categorie categorie = categorieRepository.findById((long) id)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(CATEGORIE_NOT_FOUND, new Object[]{id}, Locale.getDefault())
                ));
        return categorieMapper.toDTO(categorie);
    }

    @Override
    public List<CategorieDTO> getAllCategories() {
        return categorieRepository.findAll().stream()
                .map(categorieMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CategorieDTO getCategorieByNom(String nom) {
        return categorieRepository.findByNom(nom)
                .map(categorieMapper::toDTO)
                .orElseThrow(() -> new EntityNotFoundException(
                        messageSource.getMessage(CATEGORIE_NOT_FOUND, new Object[]{nom}, Locale.getDefault())
                ));
    }

    @Override
    public boolean isNomCategorieDejaUtilise(String nom) {
        return categorieRepository.existsByNom(nom);
    }
}
