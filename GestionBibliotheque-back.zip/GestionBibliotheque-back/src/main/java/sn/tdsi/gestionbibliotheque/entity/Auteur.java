package sn.tdsi.gestionbibliotheque.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="auteur")
public class Auteur {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long idAuteur;

    @Column(name = "nom", nullable = false, length = 100)
    private String nom;

    @Column(nullable = false, length = 100)
    private String prenom;

    // ICI : Change "prenom" par "nationalite" (ou retire carrément le name)
    @Column(name = "nationalite", nullable = false, length = 100)
    private String nationalite;
}