package sn.tdsi.gestionbibliotheque.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sn.tdsi.gestionbibliotheque.entity.Editeur;

import java.util.Optional;

@Repository
public interface EditeurRepository extends JpaRepository<Editeur, Long> {

    Optional<Editeur> findByNom(String nom);

    boolean existsByNom(String nom);
}
