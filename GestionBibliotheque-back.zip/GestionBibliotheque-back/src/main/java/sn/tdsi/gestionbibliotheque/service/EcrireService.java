package sn.tdsi.gestionbibliotheque.service;

import java.util.List;

// On retire @Service ici (il doit être sur l'implémentation, pas l'interface)
public interface EcrireService {

    /**
     * Associe un auteur à un livre.
     * Utilisation de Long pour la compatibilité JPA/Hibernate.
     */
    boolean associerAuteurLivre(Long idAuteur, Long idLivre);

    /**
     * Supprime la relation entre un auteur et un livre.
     */
    boolean dissocierAuteurLivre(Long idAuteur, Long idLivre);

    /**
     * Récupère les IDs des auteurs ayant écrit un livre spécifique.
     */
    List<Long> getIdsAuteursParLivre(Long idLivre);

    /**
     * Récupère les IDs des livres écrits par un auteur spécifique.
     */
    List<Long> getIdsLivresParAuteur(Long idAuteur);
}