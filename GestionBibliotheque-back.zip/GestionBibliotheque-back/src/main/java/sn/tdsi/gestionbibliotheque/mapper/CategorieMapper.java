package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.CategorieDTO;
import sn.tdsi.gestionbibliotheque.entity.Categorie;

@Mapper(componentModel = "spring")
public interface CategorieMapper {
    CategorieDTO toDTO(Categorie categorie);
    Categorie fromDTO(CategorieDTO dto);
}
