package sn.tdsi.gestionbibliotheque.service;

import sn.tdsi.gestionbibliotheque.entity.Utilisateur;
import java.util.List;

public interface UtilisateurService {

    boolean inscrireUtilisateur(Utilisateur utilisateur);

    boolean modifierUtilisateur(Utilisateur utilisateur);

    boolean supprimerUtilisateur(Long idUtilisateur);

    Utilisateur getUtilisateurParId(Long idUtilisateur);

    List<Utilisateur> getTousLesUtilisateurs();

    Utilisateur authentifierUtilisateur(String email, String motDePasse);

    List<Utilisateur> rechercherUtilisateurs(String critere);

    boolean changerMotDePasse(Long idUtilisateur, String ancienMotDePasse, String nouveauMotDePasse);

    boolean estEmailDejaUtilise(String email);
}
