package sn.tdsi.gestionbibliotheque.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import sn.tdsi.gestionbibliotheque.entity.Livre;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LivreDTO {

    private int idLivre;

    @NotBlank(message = "Le titre ne doit pas être vide")
    private String titre;

    @NotBlank(message = "La référence ne doit pas être vide")
    private String reference;

    @NotNull(message = "Le statut du livre est obligatoire")
    private Livre.Status status;

    @PositiveOrZero(message = "Le stock doit être supérieur ou égal à zéro")
    private int stocke;

    @NotBlank(message = "L'ISBN ne doit pas être vide")
    private String isbn;

    private String imageUrl;

    @NotNull(message = "L'ID de l'éditeur est obligatoire")
    private Integer idEditeur;

    @NotNull(message = "L'ID de la catégorie est obligatoire")
    private Integer idCategorie;

    @NotNull(message = "L'ID de l'auteur est obligatoire")
    private Integer idAuteur;

    private Integer idPersonnel; // Nullable si pas encore assigné
}
