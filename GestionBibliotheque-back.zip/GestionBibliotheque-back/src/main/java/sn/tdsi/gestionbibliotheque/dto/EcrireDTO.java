package sn.tdsi.gestionbibliotheque.dto;

import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EcrireDTO {

    private int id; // ID de la relation (optionnel si vous ne stockez pas)

    @Min(value = 1, message = "L'id de l'auteur doit être supérieur à 0")
    private int idAuteur;

    @Min(value = 1, message = "L'id du livre doit être supérieur à 0")
    private int idLivre;
}
