package sn.tdsi.gestionbibliotheque.constant;

public final class Messages {

    private Messages() {} // empêche l'instanciation

    public static final String AUTEUR_NOT_FOUND = "auteur.notfound";
    public static final String AUTEUR_EXISTS = "auteur.exists";
    public static final String AUTEUR_ERROR_DELETION = "auteur.errordeletion";

    public static final String LIVRE_NOT_FOUND = "livre.notfound";
    public static final String LIVRE_EXISTS = "livre.exists";
    public static final String LIVRE_ERROR_DELETION = "livre.errordeletion";
    public static final String LIVRE_NOT_AVAILABLE = "livre.notavailable";

    public static final String CATEGORIE_NOT_FOUND = "categorie.notfound";
    public static final String CATEGORIE_EXISTS = "categorie.exists";

    public static final String UTILISATEUR_NOT_FOUND = "utilisateur.notfound";
    public static final String UTILISATEUR_EXIST = "utilisateur.exists";
    public static final String UTILISATEUR_ID = "utilisateur.ID";
    public static final String UTILISATEUR_BADCREDENTIALS = "utilisateur.badcredentials";
    public static final String UTILISATEUR_INCORRECTPASSW = "utilisateur.incorrectPassW";

    public static final String EDITEUR_NOT_FOUND = "editeur.notfound";
    public static final String EDITEUR_EXISTS = "editeur.exists";

    public static final String EMPRUNT_NOT_FOUND = "editeur.exists";

    public static final String PERSONNEL_NOT_FOUND = "personnel.notfound";
    public static final String PERSONNEL_EXIST = "personnel.exists";
    public static final String PERSONNEL_ID = "personnel.ID";
    public static final String PERSONNEL_AUTH = "personnel.AUTH";
    public static final String PERSONNEL_MPASS = "personnel.MPASS";


    public static final String VALIDER_EMPRUNT = "emprunt.noactionvalide";
    public static final String REFUSER_EMPRUNT = "emprunt.errordeletion";
    public static final String RETOURNER_EMPRUNT = "emprunt.retour";



    // Ajoute les autres constantes pour les éditeurs, utilisateurs, personnel, emprunts...
}