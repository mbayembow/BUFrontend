package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.EmpruntDTO;
import sn.tdsi.gestionbibliotheque.entity.Emprunt;

@Mapper(componentModel = "spring")
public interface EmpruntMapper {
    EmpruntDTO toDTO(Emprunt emprunt);
    Emprunt fromDTO(EmpruntDTO dto);
}
