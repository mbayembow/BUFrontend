package sn.tdsi.gestionbibliotheque.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import sn.tdsi.gestionbibliotheque.entity.*;

public interface CategorieRepository extends JpaRepository<Categorie,Long> {
    // Vérifie si un nom de catégorie existe déjà
    boolean existsByNom(String nom);

    // Récupère une catégorie par son nom
    Optional<Categorie> findByNom(String nom);
}
