package sn.tdsi.gestionbibliotheque.mapper;

import org.mapstruct.Mapper;
import sn.tdsi.gestionbibliotheque.dto.UtilisateurDTO;
import sn.tdsi.gestionbibliotheque.entity.Utilisateur;

@Mapper(componentModel = "spring")
public interface UtilisateurMapper {
    UtilisateurDTO toDTO(Utilisateur utilisateur);
    Utilisateur fromDTO(UtilisateurDTO dto);
}
