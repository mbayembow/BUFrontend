package sn.tdsi.gestionbibliotheque.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import sn.tdsi.gestionbibliotheque.entity.Emprunt;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmpruntDTO {

    private int idEmprunt;

    @NotNull(message = "La date d'emprunt ne doit pas être nulle")
    private LocalDate dateEmprunt;

    private LocalDate dateRetour;

    @NotNull(message = "La date de demande ne doit pas être nulle")
    private LocalDate dateDemande;

    @NotNull(message = "Le statut de l'emprunt est obligatoire")
    private Emprunt.Statut statut;

    @NotNull(message = "L'ID de l'utilisateur est obligatoire")
    private Integer idUtilisateur;

    @NotNull(message = "L'ID du livre est obligatoire")
    private Integer idLivre;

    private Integer idPersonnel; // Peut être null si pas encore validé par le personnel
}
